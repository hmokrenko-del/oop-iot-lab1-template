#pragma once
#include <Arduino.h>

class LED {
private:
    uint8_t pin;
    bool state;

public:
    // Конструктор: зберігає номер піна й налаштовує його як вихід
    LED(uint8_t pin);

    // Увімкнути світлодіод
    void on();

    // Вимкнути світлодіод
    void off();

    // Перемкнути стан (on/off)
    void toggle();

    // Неблокуюче блимання з інтервалом intervalMs
    void blink(unsigned long intervalMs);
};