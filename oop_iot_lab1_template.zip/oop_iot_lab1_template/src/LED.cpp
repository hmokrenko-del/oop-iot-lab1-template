#include "LED.h"

LED::LED(uint8_t pin) {
    this->pin = pin;
    this->state = LOW;
    pinMode(pin, OUTPUT);
    digitalWrite(pin, state);
}

void LED::on() {
    state = HIGH;
    digitalWrite(pin, state);
}

void LED::off() {
    state = LOW;
    digitalWrite(pin, state);
}

void LED::toggle() {
    state = !state;
    digitalWrite(pin, state);
}

void LED::blink(unsigned long intervalMs) {
    static unsigned long lastSwitch = 0;
    unsigned long now = millis();
    if (now - lastSwitch >= intervalMs) {
        toggle();
        lastSwitch = now;
    }
}