#include <Arduino.h>
#include "LED.h"

// Світлодіоди підключені до GPIO2 та GPIO4 (ESP32 DevKit V1)
LED led1(2);
LED led2(4);

void setup() {
    Serial.begin(115200);
    Serial.println("Lab 1: OOP + ESP32 + LED");
}

void loop() {
    // LED1 блимає кожні 500 мс
    led1.blink(500);

    // LED2 блимає кожні 1000 мс
    led2.blink(1000);
}